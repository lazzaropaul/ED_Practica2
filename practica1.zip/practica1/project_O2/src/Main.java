import java.util.Arrays;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        int[] array = {-2, 11, -4, 13, -5, 2};
        maxSubsequenceSum_cubic(array);
    }

    /*
    Ara sumarà tot i anirà movent l'inici des d'on sumar (la 'i'),
    per tant arribarà un moment que sí passi per la suma més gran, i simplement
    entrara al if per guardar les dades necesaries. No tornara a entrar al 'if' ,
    perquè no hi haurà una suma més gran.
     */
    public static void maxSubsequenceSum_cubic (int [] a) {
        int maxSum = 0;
        int seqStart = 0;
        int seqEnd = 0;
        int numIte = 0;

        for (int i = 0; i < a.length; i++) {
            int thisSum = 0;
            numIte += 1;
            for (int j = i; j < a.length; j++) {
                numIte += 1;
                thisSum += a[j]; //Canvi a suma acumulativa

                if (thisSum > maxSum) {
                    maxSum = thisSum;
                    seqStart = i;
                    seqEnd = j;
                }
            }
        }
        System.out.println("Solucion de orden cubico");
        System.out.println("Maximo: " + maxSum);
        System.out.println("Inicio: " + seqStart + " Final: " + seqEnd);
        System.out.println("Numero de iteraciones: " + numIte);
    }
}
