import java.util.Arrays;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        int[] array = {-2, 11, -4, 13, -5, 2};
        maxSubsequenceSum_cubic(array);
    }

    /*
    Necesitem crear una altra variable per controlar l'inici de la suma. En el moment en el que trobem
    que la suma esta sent negativa, regenerem 'thisSum' a zero, així estem fent un salt a la seguent posició
    de l'array on realment la 'i' avançarà dins del for, però com si l'anterior posició no l'aguès sumat.

    D'aquesta manera cada vegada que la suma sigui negativa, regenerarà la suma a zero, per buscar un altre
    possible inici de la nova suma.
     */
    public static void maxSubsequenceSum_cubic (int [] a) {
        int maxSum = 0;
        int seqStart = 0;
        int seqEnd = 0;
        int numIte = 0;
        int thisSum = 0;
        int newStart = 0;

        for (int i = 0; i < a.length; i++) {
            numIte += 1;
            thisSum += a[i];

            if (thisSum > maxSum) {
                maxSum = thisSum;
                seqStart = newStart;
                seqEnd = i;
            }
            if (thisSum < 0){
                thisSum = 0;
                newStart = 1 + i;
            }

        }
        System.out.println("Solucion de orden cubico");
        System.out.println("Maximo: " + maxSum);
        System.out.println("Inicio: " + seqStart + " Final: " + seqEnd);
        System.out.println("Numero de iteraciones: " + numIte);
    }
}
